exports.listmenu = (prefix) => {
return` 𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨
 ● .owner
 ● .script
 ● .toimg
 ● .sticker
 ● .spamcall
 ● .jadibot
 ● .listjadibot
 ● .infoupdate
 ● .groupbot
 
 𝗔𝗡𝗢𝗡𝗬𝗠𝗢𝗨𝗦 𝗖𝗛𝗔𝗧
 ● .chat
 ● .skip
 ● .start
 ● .secret
 ● .confess
 ● .menfess
 ● .secretchat
 ● .stopchat

 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨
 ● .error
 ● .server
 ● .infouser
 ● .runtime
 ● .session
 ● .resetdb
 ● .addprem
 ● .delprem
 ● .broadcast
 ● .dashboard

 𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨
 ● .hidetag
 ● .tagall
 ● .fitnah
 ● .delete
 ● .revoke
 ● .linkgrup
 ● .setdesc
 ● .demote
 ● .antilink
 ● .promote
 ● .setppgrup
 ● .kick @tag
 ● .setnamegc
 ● .group open
 ● .group close

 𝗦𝗧𝗔𝗟𝗞𝗘𝗥 𝗠𝗘𝗡𝗨
 ● .ffstalk *id*
 ● .mlstalk *id|zone*
 ● .npmstalk *packname*
 ● .githubstalk *username*

 𝗞𝗔𝗟𝗞𝗨𝗟𝗔𝗧𝗢𝗥
 ● .kali *angka angka*
 ● .bagi *angka angka*
 ● .kurang *angka angka*
 ● .tambah *angka angka*

 𝗦𝗧𝗢𝗥𝗘 𝗠𝗘𝗡𝗨
 ● .list *<only grup>*
 ● .addlist *key@pesan*
 ● .dellist *<options>*
 ● .update *key@pesan*
 ● .proses *<reply orderan>*
 ● .done *<reply orderan>*`
}